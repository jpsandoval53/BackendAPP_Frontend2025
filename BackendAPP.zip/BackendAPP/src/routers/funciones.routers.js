import {
  crearDatos,
  consultarDatos,
  eliminarDatos,
  actualizarDatos,
} from "../controllers/funciones.controller.js";
console.log(crearDatos);
import { Router } from "express";
const router = Router();

/* configuro las rutas*/

router.post("/crear", crearDatos);
router.get("/consultar", consultarDatos);
router.delete("/eliminar", eliminarDatos);
router.put("/actualizar", actualizarDatos);

export default router;
