import connection from "../../lib/db.js";  
/* CREAR UNA FUNCIÓN ..> CREAR DATOS */

export const crearDatos = (req, res, next) => {
    console.log("Crear_Datos:", req.body.nombre);
    const { nombre, vlr_unit, categoria, referencia } = req.body;
    //console.log("He ingresado a la funcion crear_Datos!");
    //res.status(203).json({ message: req.body.nombre });
    //return;
    const sql = `insert into producto (nombre,vlr_unit,categoria, referencia ) values (?,?,?,?)`; ;
    const params = [nombre, vlr_unit, categoria, referencia];
    connection.query(sql, params, (error, results) => {
    if (error) {
      console.error("Error al insertar:", error);
      return res.status(500).json({ message: "Error al insertar", error });
    }

    return res.status(201).json({
      message: "Producto creado correctamente",
      id: results.insertId
    });
  });

};


export const consultarDatos = (req, res, next) => {
    console.log("He  creado a la función de consultar datos");
}; 

export const eliminarDatos = (req, res, next) => {
    console.log("He  creado a la función de eliminar datos");
}; 

export const actualizarDatos = (req, res, next) => {
    console.log("He  creado a la función de actualizar datos");
};
