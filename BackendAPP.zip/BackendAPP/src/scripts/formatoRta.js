const formatoRta = (codigo, idCreado, mensaje) => {
    return ({ code: codigo, idCreado: idCreado, message: mensaje })
}
export { formatoRta }